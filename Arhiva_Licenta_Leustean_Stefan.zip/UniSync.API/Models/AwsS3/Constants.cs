﻿namespace UniSync.Api.Models.AwsS3
{
    public class Constants
    {
        public static readonly string AccessKey = "AccessKey";
        public static readonly string SecretKey = "SecretKey";
    }
}
