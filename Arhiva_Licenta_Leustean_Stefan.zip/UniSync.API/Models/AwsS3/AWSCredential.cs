﻿namespace UniSync.Api.Models.AwsS3
{
    public class AWSCredential
    {
        public string AwsKey { get; set; } = "";
        public string AwsSecretKey { get; set; } = "";
    }
}
