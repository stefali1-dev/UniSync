using UniSync.Application.Features.UserPhotos.Queries.GetUserPhoto;
using UniSync.Application.Features.Users.Commands.DeleteUser;
using UniSync.Application.Features.Users.Commands.UpdateRole;
using UniSync.Application.Features.Users.Commands.UpdateUser;
using UniSync.Application.Features.Users.Queries.GetAll;
using UniSync.Application.Features.Users.Queries.GetByEmail;
using UniSync.Application.Features.Users.Queries.GetById;
using UniSync.Application.Features.Users.Queries.Search;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniSync.API.Controllers;
using UniSync.Application.Contracts.Interfaces;

namespace UniSync.Api.Controllers;

public class UsersController : ApiControllerBase
{
    private readonly IUserService userService;

    public UsersController(IUserService userService)
    {
        this.userService = userService;
    }

    //[Authorize(Roles = "User")]
    //[HttpPost]
    //[ProducesResponseType(StatusCodes.Status201Created)]
    //public async Task<IActionResult> Create(CreateUserCommand command)
    //{
    //    var result = await Mediator.Send(command);
    //    if (!result.Success)
    //    {
    //        return BadRequest(result);
    //    }
    //    return Ok(result);
    //}

    //[Authorize(Roles = "User")]
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(Guid id, UpdateUserCommand command)
    {
        if (id != command.Id)
        {
            return BadRequest("The ids must be the same!");
        }
        var result = await Mediator.Send(command);
        if (!result.Success)
        {
            return BadRequest(result);
        }
        return Ok(result);
    }

    //[Authorize(Roles = "User")]
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll()
    {
        var result = await Mediator.Send(new GetAllUsersQuery());
        return Ok(result);
    }

    [Authorize(Roles = "Admin")]
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(Guid id)
    {
        var command = new DeleteUserCommand { UserId = id };
        var result = await Mediator.Send(command);
        if (!result.Success)
        {
            return BadRequest(result);
        }
        return Ok(result);
    }

    //[Authorize(Roles = "User")]
    [HttpGet("ById/{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetUserById(string id)
    {
        var query = new GetByIdUserQuery { UserId = id };
        var result = await Mediator.Send(query);
        if(!result.Success)
        {
            if(result.Message == $"User with id {id} not found")
            {
                return NotFound(result);
            }
            return BadRequest(result);
        }
        return Ok(result);
    }

    //[Authorize(Roles = "User")]
    [HttpGet("ByEmail/{email}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetUserByEmail(string email)
    {
        var query = new GetByEmailUserQuery { Email = email };
        var result = await Mediator.Send(query);
        if (!result.Success)
        {
            return BadRequest(result);
        }
        return Ok(result);
    }

    [HttpGet("Professors")]
    public async Task<IActionResult> GetAllProfessors()
    {
        try
        {
            var professors = await userService.GetAllProfessors();
            return Ok(professors);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpGet("Students")]
    public async Task<IActionResult> GetAllStudents()
    {
        try
        {
            var students = await userService.GetAllStudents();
            return Ok(students);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpGet("Professors/search")]
    public async Task<IActionResult> SearchProfessors([FromQuery] string searchValue)
    {
        try
        {
            var professors = await userService.SearchProfessors(searchValue);
            return Ok(professors);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpGet("Students/search")]
    public async Task<IActionResult> SearchStudents([FromQuery] string searchValue)
    {
        try
        {
            var students = await userService.SearchStudents(searchValue);
            return Ok(students);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    //[Authorize(Roles ="Admin")]
    [HttpPut("/role/{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateRole(Guid id, UpdateUserRoleCommand command)
    {
        if (id != command.UserId)
        {
            return BadRequest("The ids must be the same!");
        }
        var result = await Mediator.Send(command);
        if (!result.Success)
        {
            return BadRequest(result);
        }
        return Ok(result);
    }


    //[Authorize(Roles = "User")]
    [HttpGet("search/{searchValue}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> SearchUsers(string searchValue)
    {
        var query = new SearchUsersQuery { SearchValue = searchValue };
        var result = await Mediator.Send(query);
        return Ok(result);
    }

    //[HttpPost]
    //[Route("reset-code")]
    //[ProducesResponseType(StatusCodes.Status200OK)]
    //public async Task<IActionResult> ResetCode(ResetCodeCommand command)
    //{
    //    var result = await Mediator.Send(command);
    //    if (!result.Success)
    //    {
    //        return BadRequest(result);
    //    }
    //    return Ok(result);
    //}
}
