export function isNil<T>(value: T): boolean {
  return value == null;
}
