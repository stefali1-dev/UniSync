export interface ChannelCreationDto {
  channelName: string;
  chatUsersIds: string[];
}
