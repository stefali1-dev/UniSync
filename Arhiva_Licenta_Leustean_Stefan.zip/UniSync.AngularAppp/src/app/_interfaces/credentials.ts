export interface Credentials {
    registrationId: string;
    email: string;
    password: string;
  }