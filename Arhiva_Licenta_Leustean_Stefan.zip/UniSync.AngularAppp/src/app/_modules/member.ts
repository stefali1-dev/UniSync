export interface Member {
  token: string;
  userId: string | null;
  email: string | null;
  username: string | null;
  role: string | null;
  appUserId: string | null;
}
