﻿namespace UniSync.Application.Features.Email.Commands.SendResetCodeEmail
{
    internal class SendResetCodeEmailQuery
    {
    }
}
