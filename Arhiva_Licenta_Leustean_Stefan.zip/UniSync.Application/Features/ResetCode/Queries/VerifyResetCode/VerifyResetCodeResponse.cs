﻿using UniSync.Application.Responses;

namespace UniSync.Application.Features.ResetCode.Queries.VerifyResetCode
{
    public class VerifyResetCodeResponse : BaseResponse
    {
        public VerifyResetCodeResponse() : base()
        {
        }
    }
}