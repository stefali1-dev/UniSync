﻿using UniSync.Application.Responses;

namespace UniSync.Application.Features.ResetCode.Commands.CreateResetCode
{
    public class CreateResetCodeCommandResponse : BaseResponse
    {
        public CreateResetCodeCommandResponse() : base()
        {

        }

    }
}