﻿using UniSync.Application.Responses;

namespace UniSync.Application.Features.Users.Commands.DeleteUser
{
    public class DeleteUserCommandResponse : BaseResponse
    {
        public DeleteUserCommandResponse() : base()
        {
            
        }
    }
}