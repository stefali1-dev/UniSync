﻿namespace UniSync.Application.Features.Users.Commands.UpdateRole
{
    public class UpdateUserRoles
    {
            public const string Admin = "Admin";
            public const string User = "User";
    }
}
