﻿using UniSync.Application.Responses;

namespace UniSync.Application.Features.Users.Commands.UpdateRole
{
    public class UpdateUserRoleCommandResponse : BaseResponse
    {
        public UpdateUserRoleCommandResponse() : base()
        {
            
        }
    }
}