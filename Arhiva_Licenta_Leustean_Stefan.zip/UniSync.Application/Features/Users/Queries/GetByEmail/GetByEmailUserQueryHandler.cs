﻿using UniSync.Application.Persistence;
using MediatR;

namespace UniSync.Application.Features.Users.Queries.GetByEmail
{
    public class GetByEmailUserQueryHandler : IRequestHandler<GetByEmailUserQuery, GetByEmailUserQueryReponse>
    {
        private readonly IUserManager userRepository;

        public GetByEmailUserQueryHandler(IUserManager userRepository)
        {
            this.userRepository = userRepository;
        }

        public async Task<GetByEmailUserQueryReponse> Handle(GetByEmailUserQuery request, CancellationToken cancellationToken)
        {
            var result = await userRepository.FindByEmailAsync(request.Email);
            if (!result.IsSuccess)
                return new GetByEmailUserQueryReponse { Success = false, Message = result.Error };
            var userDto = result.Value;
            return new GetByEmailUserQueryReponse
            {
                Success = true,
                User = new UserDto
                {
                    UserId = userDto.UserId,
                    FirstName = userDto.FirstName,
                    LastName = userDto.LastName,
                    Email = userDto.Email,
                    Roles = userDto.Roles
                }
            };
        }
    }
}
