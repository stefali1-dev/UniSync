namespace UniSync.Application.Features.Users
{
    public class UserCloudPhotoDto
    {
        public Guid UserPhotoId { get; set; }
        public string PhotoUrl { get; set; }
    }
}
