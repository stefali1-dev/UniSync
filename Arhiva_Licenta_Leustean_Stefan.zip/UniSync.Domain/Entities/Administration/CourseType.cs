﻿namespace UniSync.Domain.Entities.Administration
{
    public enum CourseType
    {
        Mandatory = 1,
        Facultative,
        Optional
    }
}
