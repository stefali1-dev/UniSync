﻿namespace UniSync.Domain.Common
{
    public enum ProfessorType
    {
        Course = 1,
        Lab
    }
}
