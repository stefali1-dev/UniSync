﻿namespace UniSync.Identity.Models
{
    public static class UserRoles
    {
        public const string Admin = "Admin";
        public const string User = "User";
        public const string Student = "Student";
        public const string Professor = "Professor";
        public const string Staff = "Staff";

    }
}
